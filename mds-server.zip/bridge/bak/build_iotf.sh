#!/bin/sh

if [ "$1" = "" ]; then 
   echo "Usage: $0 <bm user> <bm password> <space> <container namespace> <container instance name> <container public IP address>"
   exit 1
fi

if [ "$2" = "" ]; then 
   echo "Usage: $0 <bm user> <bm password> <space> <container namespace> <container instance name> <container public IP address>"
   exit 1
fi

if [ "$3" = "" ]; then
   echo "Usage: $0 <bm user> <bm password> <space> <container namespace> <container instance name> <container public IP address>"
   exit 1
fi

if [ "$4" = "" ]; then
   echo "Usage: $0 <bm user> <bm password> <space> <container namespace> <container instance name> <container public IP address>"
   exit 1
fi

if [ "$5" = "" ]; then
   echo "Usage: $0 <bm user> <bm password> <space> <container namespace> <container instance name> <container public IP address>"
   exit 1
fi

if [ "$6" = "" ]; then
   echo "Usage: $0 <bm user> <bm password> <space> <container namespace> <container instance name> <container public IP address>"
   exit 1
fi

cd /home/ibmcloud/bridge/staging

set -x
ice login -u $1 -p $2 -s $3
ice namespace set $4
ice rmi registry.ng.bluemix.net/$4/mbed_iotf_img:techcon2015
sleep 30
ice build -t registry.ng.bluemix.net/$4/mbed_iotf_img:techcon2015 .
sleep 30
cf login -u $1 -p $2 -s $3 -a api.ng.bluemix.net
/home/arm/bridge/run_iotf.sh $4 $5 $6
