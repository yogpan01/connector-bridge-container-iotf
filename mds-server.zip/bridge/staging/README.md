Purpose:

    This is an implementation of a container running the mbed Device Server (v2.3).
    This implementation supports both docker-based environments as well as the Bluemix ICE container environment
    In addition to the mDS server, MQTT connectivity support is provided through a companion service.
    The container instance contains the MQTT mosquitto broker by default as the targeted MQTT broker

Prequisites (Docker)
    1). Ubuntu or other Linux flavor with docker installed


Prerequisites (ICE)
    1). Bluemix account setup
    2). Enrolled in the Bluemix container beta program
    3). Public IP address for your Bluemix account/container established
    4). IBM ICE CLI installed locally (Ubuntu is the preferred local environment)

Container Contents:
    This container will implement the following:
    1). An instance of mDS (v2.3) running through Oracle's JRE 7 + Unlimited JCE
    2). An instance of the mosquitto MQTT broker installed and running. mDS companion MQTT service points to it.
    3). SSH administrative access (keys provided but can be changed if desired... see "ssh-keys.tar")
    4). non-root account ("arm") created as the default account to run mDS and mosquitto in 
    5). Default "run" script invokes the container: /home/arm/start_instance.sh

Building for Docker:
    1). myhost% ./build_docker.sh
    2). myhost% ./run_docker.sh

Building for Bluemix:
    1). myhost% ./build_bm.sh my_bm_account_username my_bm_account_password
    2). myhost% ./run_bm.sh my.public.bm.ipaddress
